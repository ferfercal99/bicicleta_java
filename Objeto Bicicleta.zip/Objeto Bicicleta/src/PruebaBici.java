import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PruebaBici {
	
	//Busca al ganador de la competición(El más rápido)
	public static String ganador(List<Bicicleta> x) {
		return x.stream().max((i,j)->i.getVelocidad()-j.getVelocidad()).get().getNombre();
	}
	
	//Busca al competidor por su nombre y devuelve todos sus datos
	public static Bicicleta buscacompetidor(List<Bicicleta> x, String nombre) {
		return x.stream().filter(i->i.getNombre()==nombre).findFirst().get();
	}
	
	//Ordena los competidores de más rápidos a más lentos
	public static void ordenaCompetidoresPorVelocidad(List<Bicicleta>x) {
		x.stream().sorted(Comparator.comparing(Bicicleta::getVelocidad).reversed()).map(i->i.getNombre()).forEach(System.out::println);
	}
	
	//Ordena los competidores por orden alfabético
	public static void ordenaCompetidoresPorNombre(List<Bicicleta>x) {
		x.stream().sorted(Comparator.comparing(Bicicleta::getNombre)).forEach(System.out::println);
	}
	
	public static void main(String[] args) {
		Bicicleta competidor1=new Bicicleta();
		Bicicleta competidor2= new Bicicleta();
		Bicicleta competidor3=new Bicicleta();
		Bicicleta competidor4=new Bicicleta();
		
		
		competidor1.cambiaPinon(5);
		competidor1.cambiaPlato(6);
		competidor1.acelerar(20);
		competidor1.setNombre("Ramon");
		
		
		competidor2.cambiaPinon(7);
		competidor2.cambiaPlato(3);
		competidor2.acelerar(30);
		competidor2.frenar(5);
		competidor2.setNombre("Fernando");
		
		
		competidor3.cambiaPinon(9);
		competidor3.cambiaPlato(2);
		competidor3.acelerar(60);
		competidor3.frenar(45);
		competidor3.setNombre("Jaime");
		
		
		competidor4.setNombre("Andrea");
		competidor4.acelerar(23);
		competidor4.cambiaPinon(7);
		competidor4.cambiaPlato(4);
		
		
		List<Bicicleta> competicion= new ArrayList<Bicicleta>();
		competicion.add(competidor1);
		competicion.add(competidor2);
		competicion.add(competidor3);
		competicion.add(competidor4);
		System.out.println(ganador(competicion));
		System.out.println(buscacompetidor(competicion, "Jaime"));
		ordenaCompetidoresPorVelocidad(competicion);
		ordenaCompetidoresPorNombre(competicion);
		
	}
	
	

}
