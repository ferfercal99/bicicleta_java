import java.util.Objects;

public class Bicicleta {
	String nombre="";
	int velocidad=0;
	int pinon=1;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	int plato=1;
	
	void cambiaPinon(int nuevoPinon) {
		pinon=nuevoPinon;
	}
	void cambiaPlato(int nuevoPlato) {
		plato=nuevoPlato;
	}
	
	void acelerar(int incremento) {
		velocidad=velocidad+incremento;
	}
	void frenar(int decremento) {
		velocidad=velocidad-decremento;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(nombre, pinon, plato, velocidad);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bicicleta other = (Bicicleta) obj;
		return Objects.equals(nombre, other.nombre) && pinon == other.pinon && plato == other.plato
				&& velocidad == other.velocidad;
	}
	public int getVelocidad() {
		return velocidad;
	}
	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}
	public int getPinon() {
		return pinon;
	}
	public void setPinon(int pinon) {
		this.pinon = pinon;
	}
	public int getPlato() {
		return plato;
	}
	@Override
	public String toString() {
		return "nombre=" + nombre + ", velocidad=" + velocidad + ", pinon=" + pinon + ", plato=" + plato
				;
	}
	public void setPlato(int plato) {
		this.plato = plato;
	}
}
